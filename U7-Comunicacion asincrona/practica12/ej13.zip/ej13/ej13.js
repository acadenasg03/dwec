function cargarPokemon(){
      let nombre = document.getElementById("nombre").value;
      fetch("https://pokeapi.co/api/v2/pokemon/" + nombre.toLowerCase())
      .then(res => res.json())
      .then(datos => {
            let titulo = document.createElement("h2")
            titulo.innerHTML = nombre.toUpperCase() + "#" + datos.order;
            document.body.appendChild(titulo);
            let img = document.createElement("img");
            img.setAttribute("src",datos.sprites.front_default);
            img.setAttribute("alt","foto pokemon");
            document.body.appendChild(img);
            let altura = document.createElement("p");
            altura.innerHTML = "Altura: " + datos.height;
            document.body.appendChild(altura);
            let peso = document.createElement("p");
            peso.innerHTML = "Peso: " + datos.weight;
            document.body.appendChild(peso);
            let stats = document.createElement("h3")
            stats.innerHTML = "Estadicticas";
            document.body.appendChild(stats);

      })

}
